﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.IO;

namespace SWCylinderTry2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double userDiaInput;
        double userHeightInput;
    
        ModelDoc2 userDoc;
        int fileError;
        int fileWarning;
        string fileName;
        string drwName;

        Dimension swDimension;
      
        ModelDocExtension swModelDocExt = default(ModelDocExtension);
        ModelDoc2 swModelDoc = default(ModelDoc2);
        PackAndGo swPackAndGo = default(PackAndGo);

        bool boolStatus = false;

        private void button1_Click(object sender, EventArgs e)
        {
            
            double diaResult;
            double heightResult;
  
            double.TryParse(txtDia.Text, out diaResult);
            double.TryParse(txtHeight.Text, out heightResult);
            

            if (diaResult >0 && heightResult >0)
            {
                SldWorks.SldWorks swApp;
                swApp = new SldWorks.SldWorks();
               // swApp.Visible = true;

                string openFile = null;
                int pgWarnings = 0;
                int pgErrors = 0;
                int namesCount = 0;
                string myPath = null;
                int[] statuses = null;

                // Open assembly
                //openFile = @"R:\SUPSI\01. CreateCylinderTemplate\_.SLDPRT";
                openFile = @"\\pdmsupport\ENG-STD\SUPSI\01. CreateCylinderTemplate\_.SLDPRT";
                swModelDoc = (ModelDoc2)swApp.OpenDoc6(openFile, (int)swDocumentTypes_e.swDocPART, (int)swOpenDocOptions_e.swOpenDocOptions_Silent, "", ref pgErrors, ref pgWarnings);
                swModelDocExt = (ModelDocExtension)swModelDoc.Extension;

                /***REMOVE THIS*****/
                MessageBox.Show("File ready for Pack and go...");

                // Get Pack and Go object
                swPackAndGo = (PackAndGo)swModelDocExt.GetPackAndGo();

                // Get number of documents in assembly
                namesCount = swPackAndGo.GetDocumentNamesCount();

                // Include any drawings, SOLIDWORKS Simulation results, and SOLIDWORKS Toolbox components
                swPackAndGo.IncludeDrawings = true;
                
                swPackAndGo.IncludeSimulationResults = false;
                
                swPackAndGo.IncludeToolboxComponents = false;

                object fileNames;
                object[] pgFileNames = new object[namesCount - 1];
                boolStatus = swPackAndGo.GetDocumentNames(out fileNames);
                pgFileNames = (object[])fileNames;

                // Get current save-to paths and filenames of the assembly's documents
                object pgFileStatus;
                boolStatus = swPackAndGo.GetDocumentSaveToNames(out fileNames, out pgFileStatus);
                pgFileNames = (object[])fileNames;

                // Set folder where to save the files
                myPath = txtFolderPath.Text+"\\";
                boolStatus = swPackAndGo.SetSaveToName(true, myPath);

                // Flatten the Pack and Go folder structure; save all files to the root directory
                swPackAndGo.FlattenToSingleFolder = true;

                // Add a prefix and suffix to the filenames
                swPackAndGo.AddPrefix = txtFileName.Text;
                //swPackAndGo.AddSuffix = "_PackAndGo";

                // Pack and Go
                statuses = (int[])swModelDocExt.SavePackAndGo(swPackAndGo);

                /***REMOVE THIS*****/
                MessageBox.Show("Pack and Go Completed...");

                swApp.CloseDoc("_.SLDPRT");

                userDiaInput = diaResult;
                userHeightInput = heightResult;
       
                swApp.Visible = true;

                fileName = txtFolderPath.Text + txtFileName.Text + "_.SLDPRT";

                swApp.OpenDoc6(fileName, (int)swDocumentTypes_e.swDocPART, (int)swOpenDocOptions_e.swOpenDocOptions_Silent, "", ref fileError, ref fileWarning);

                userDoc = swApp.ActiveDoc;

                boolStatus = userDoc.Extension.SelectByID2("D1@Sketch1@"+txtFileName.Text+"_.SLDPRT", "DIMENSION", 0, 0, 0, false, 0, null, 0);

                swDimension = (Dimension)userDoc.Parameter("D1@Sketch1@"+txtFileName.Text+"_.SLDPRT");
                fileError = (int)swDimension.SetSystemValue3(diaResult/1000, (int)swSetValueInConfiguration_e.swSetValue_InThisConfiguration, null);
                
                boolStatus = userDoc.EditRebuild3();
                userDoc.ViewZoomtofit2();

                userDoc.ClearSelection2(true);

                boolStatus = userDoc.Extension.SelectByID2("Boss-Extrude1", "BODYFEATURE", 0, 0, 0, false, 0, null, 0);

                swDimension = (Dimension)userDoc.Parameter("D1@Boss-Extrude1@"+txtFileName.Text + "_.SLDPRT");
                fileError = (int)swDimension.SetSystemValue3(heightResult/1000, (int)swSetValueInConfiguration_e.swSetValue_InThisConfiguration, null);

                boolStatus = userDoc.EditRebuild3();
                userDoc.ViewZoomtofit2();

                boolStatus = userDoc.EditRebuild3();

                boolStatus = userDoc.Save3((int)swSaveAsOptions_e.swSaveAsOptions_Silent, ref fileError, ref fileWarning);

                drwName = txtFolderPath.Text + txtFileName.Text + "_.SLDDRW";

                swApp.OpenDoc6(fileName, (int)swDocumentTypes_e.swDocDRAWING, (int)swOpenDocOptions_e.swOpenDocOptions_Silent, "", ref fileError, ref fileWarning);

                userDoc = swApp.ActiveDoc;

                boolStatus = userDoc.EditRebuild3();

                boolStatus = userDoc.Save3((int)swSaveAsOptions_e.swSaveAsOptions_Silent, ref fileError, ref fileWarning);

                swApp.ExitApp();

                MessageBox.Show("Cylinder part and drawing files created successfully!!!", "Complete", MessageBoxButtons.OK);

                Application.Exit();
       
            }
            
            else
            {
                MessageBox.Show("You must type positive, non-zero, numeric values in both Radius & Depth.");

                Application.Exit();
                //Close form and continue
                //Close();    
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
