﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SWCylinderTry2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double userDiaInput;
        double userHeightInput;
        
        
        ModelDoc2 userDoc;
        int fileError;
        int fileWarning;
        string fileName;
        Dimension swDimension;
        SelectionMgr swSelectionManager;
        Feature swFeature;

        ModelDocExtension swModelDocExt = default(ModelDocExtension);
        bool boolStatus = false;

        private void button1_Click(object sender, EventArgs e)
        {
            
            double diaResult;
            double heightResult;
  
            double.TryParse(txtDia.Text, out diaResult);
            double.TryParse(txtHeight.Text, out heightResult);

            if(diaResult >0 && heightResult >0)
            {
                userDiaInput = diaResult;
                userHeightInput = heightResult;
                
                SldWorks.SldWorks swApp;

                swApp = new SldWorks.SldWorks();
                swApp.Visible = true;

                fileName = "C:\\Users\\supsi\\Desktop\\New macro check\\01. 05.12.2018\\EqCylinder.SLDPRT";

                swApp.OpenDoc6(fileName, (int)swDocumentTypes_e.swDocPART, (int)swOpenDocOptions_e.swOpenDocOptions_Silent, "", ref fileError, ref fileWarning);

                userDoc = swApp.ActiveDoc;

                userDoc.ClearSelection2(true);

                //Selecting the Sketch

                boolStatus = userDoc.Extension.SelectByID2("Sketch1", "SKETCH", 0, 0, 0, false, 0, null, 0);
               
                //   userDoc.EditSketch();

                //   boolStatus=userDoc.Extension.SelectByID2("Boss-Extrude1@EqCylinder.SLDPRT", "DIMENSION", 0, 0, 0, false, 0, null, 0);

                boolStatus = userDoc.Extension.SelectByID2("Boss-Extrude1", "DIMENSION", 0, 0, 0, false, 0, null, 0);
                
                swSelectionManager = (SelectionMgr)userDoc.SelectionManager;

                swFeature = (Feature)swSelectionManager.GetSelectedObject6(1, -1);

                swDimension = (Dimension)swFeature.Parameter("D1@Boss-Extrude1@EqCylinder.SLDPRT");

                fileError = swDimension.SetSystemValue3(heightResult, (int)swSetValueInConfiguration_e.swSetValue_InThisConfiguration, null);

                userDoc.EditRebuild3();

                boolStatus = swModelDocExt.SelectByID2("D1@Sketch1@EqCylinder.SLDPRT", "DIMENSION", 0, 0, 0, false, 0, null, 0);

                swDimension = (Dimension)userDoc.Parameter("D1@Sketch1@EqCylinder.SLDPRT");
                fileError = (int)swDimension.SetSystemValue3(diaResult, (int)swSetValueInConfiguration_e.swSetValue_InThisConfiguration, null);

                userDoc.ClearSelection2(true);

                //Editing 

                boolStatus = userDoc.Extension.SelectByID2("Boss-Extrude1", "BODYFEATURE", 0, 0, 0, false, 0, null, 0);

                userDoc.ClearSelection2(true);

                //Zoom to fit

                userDoc.ViewZoomtofit2();
                boolStatus = userDoc.EditRebuild3();

                userDoc.ClearSelection2(true);

                //save document
                
                boolStatus = userDoc.Save3(1, fileError, fileWarning);

                //Close document

                swApp.CloseDoc("EqCylinder.SLDPRT");

   
                //   swApp.ExitApp();

                swApp = null;

                //   Application.Exit();

            }
            
            else
            {
                MessageBox.Show("You must type positive, non-zero, numeric values in both Radius & Depth.");

                //Close form and continue
                //Close();    
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
