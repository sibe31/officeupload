﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SolidWorks.Interop.sldworks;
using SolidWorks.Interop.swconst;
using System.Runtime.InteropServices;

namespace BossExtrudeTry1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Feature myFeature;
        ModelDoc2 userDoc;
        RefPlane myRefPlane;

        bool boolStatus;

        private void button1_Click(object sender, EventArgs e)
        {

            double diaResult;
            double heightResult;
          
           // int sketchStatus = 0;

            double.TryParse(txtDia.Text, out diaResult);
            double.TryParse(txtHeight.Text, out heightResult);

            SldWorks.SldWorks swApp;

            swApp = new SldWorks.SldWorks();

            swApp.Visible = true;

            userDoc =(ModelDoc2)swApp.NewDocument("C:\\Users\\supsi\\Desktop\\Templates\\Enovia_Part 2015x_SW17.prtdot", 0, 0, 0);

            userDoc = (ModelDoc2)swApp.ActiveDoc;

            boolStatus = userDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, true, 0, null, 0);
            myRefPlane = (RefPlane)userDoc.FeatureManager.InsertRefPlane(8, 0, 0, 0, 0, 0); //edit 8,0.01
            boolStatus = userDoc.Extension.SelectByID2("Front Plane", "PLANE", 0, 0, 0, true, 0, null, 0);
            myRefPlane = (RefPlane)userDoc.FeatureManager.InsertRefPlane(8, heightResult+0.00001, 0, 0, 0, 0);

            boolStatus = userDoc.Extension.SelectByID2("Plane2", "PLANE", 0, 0, 0, false, 0, null, 0);

            object vSkLines = null;
           // vSkLines = userDoc.SketchManager.CreateCornerRectangle(-0.0250462141853123, 0.0157487558892494, 0, 0.0275128867944718, -0.015559011842391, 0);

            vSkLines = userDoc.SketchManager.CreateCircleByRadius(0, 0, 0, diaResult/2);

            //sketchStatus = userDoc.SketchManager.FullyDefineSketch(true, true, (int)swSketchFullyDefineRelationType_e.swSketchFullyDefineRelationType_Coincident, false, 1, null, 1, null, 0, 0);

            userDoc.SketchManager.InsertSketch(true);

            // Sketch to extrude
            boolStatus = userDoc.Extension.SelectByID2("Sketch1", "SKETCH", 0, 0, 0, false, 0, null, 0);
            // Start condition reference
            boolStatus = userDoc.Extension.SelectByID2("Plane2", "PLANE", 0.00105020593408751, -0.00195369982668282, 0.0248175428318827, true, 32, null, 0);
            // End condition reference
            boolStatus = userDoc.Extension.SelectByID2("Plane1", "PLANE", 0.0068370744701368, -0.004419862088339, 0.018892268568016, true, 1, null, 0);

      
     /*
           myFeature = (Feature)userDoc.FeatureManager.FeatureExtrusion3(true, false, true, (int)swEndConditions_e.swEndCondOffsetFromSurface,
           0, 0.003, 0.003, false, false, false,false, 0.0174532925199433, 0.0174532925199433, false, false, false, false, true, true, 
           true,(int)swStartConditions_e.swStartSurface, 0, false);

    */
            myFeature = (Feature)userDoc.FeatureManager.FeatureExtrusion3(true, false, true, (int)swEndConditions_e.swEndCondOffsetFromSurface, 
                (int)swEndConditions_e.swEndCondBlind, 0.00001, 0.00, false, false, false, false, 0.01, 0.01, false, false, false, false, true, 
                true, true, (int)swStartConditions_e.swStartSurface, 0, false);

            //SaveAsDocument

            boolStatus = userDoc.SaveAs4("C:\\Users\\supsi\\Desktop\\saveas\\"+ txtFileName.Text +".SLDPRT", 0, 1, 4, 1);


            

            //save document
            //  boolstatus = Part.Save3(1, fileError, fileWarning);

            //  swApp.ExitApp();
            //  swApp = null;

        }

        private void lblFilePath_Click(object sender, EventArgs e)
        {

        }

        // public SldWorks swApp;

    }
}
